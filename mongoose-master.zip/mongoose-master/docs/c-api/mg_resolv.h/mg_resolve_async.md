---
title: "mg_resolve_async()"
decl_name: "mg_resolve_async"
symbol_kind: "func"
signature: |
  int mg_resolve_async(struct mg_mgr *mgr, const char *name, int query,
                       mg_resolve_callback_t cb, void *data);
---

See `mg_resolve_async_opt()` 

